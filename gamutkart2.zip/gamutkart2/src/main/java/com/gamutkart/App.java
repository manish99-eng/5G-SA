package com.gamutkart;

public class App 
{
    public static void main( String[] args )
    {
		int i;
		int k;
		int j;
		int l;

		for(i=0;i<=30;i++)
		{
			i += 5;
   		}
	 }
}
